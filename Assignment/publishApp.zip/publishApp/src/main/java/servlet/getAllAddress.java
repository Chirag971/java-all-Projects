/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import Bean.PublishBeanLocal;
import Entities.Address;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin
 */
@WebServlet(name = "getAllAddress", urlPatterns = {"/getAddress"})
public class getAllAddress extends HttpServlet {

    @EJB
    PublishBeanLocal pub;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            int cid = Integer.parseInt(request.getParameter("cid"));
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet getAllAddress</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<form action='sAddress' method='post'><br><br>"); // Use the appropriate action URL
            out.println("<label for='field2'>Search By Street :</label>");
            out.println("<input type='text' id='street' name='street'>");
            out.println("<input type='submit' value='Search'>");
            out.println("</form><br><br>");
            out.println("<form action='sAddress' method='post'>"); // Use the appropriate action URL
            out.println("<label for='field2'>Search By City :</label>");
            out.println("<input type='text' id='city' name='city'>");
            out.println("<input type='submit' value='Search'>");
            out.println("</form><br><br>");
            out.println("<form action='sAddress' method='post'>"); // Use the appropriate action URL
            out.println("<label for='field2'>Search By State :</label>");
            out.println("<input type='text' id='state' name='state'>");
            out.println("<input type='submit' value='Search'>");
            out.println("</form><br><br>");
             out.println("<form action='sAddress' method='post'>"); // Use the appropriate action URL
            out.println("<label for='field2'>Search By Zip :</label>");
            out.println("<input type='text' id='zip' name='zip'>");
            out.println("<input type='submit' value='Search'>");
            out.println("</form><br><br>");
            Collection<Address> address = pub.getAddressesofCustomer(cid);
            if (address == null) {
                out.println("<div style=\"text-align:center;\">");
                out.println("<h3> No Address Added  </h3>");
                out.print("<a href='addAddress?cId=" + cid + "'>Insert</a>");
                out.println("</div>");
            } else {

                out.println("<div style=\"text-align:center;\">");
                out.print("<a href='addAddress?cId=" + cid + "'>Add Address</a><br><br>");
                out.println("<table border='1' align='center'>");
                out.println("<tr>");
                out.println("<th>Street</th>");
                out.println("<th>City</th>");
                out.println("<th>State</th>");
                out.println("<th>Zip</th>");
                out.println("<th>Options</th>");
                out.println("</tr>");
                for (Address ad : address) {
                    out.println("<tr>");
                    out.println("<td>" + ad.getStreet() + "</td>");
                    out.println("<td>" + ad.getCity() + "</td>");
                    out.println("<td>" + ad.getState() + "</td>");
                    out.println("<td>" + ad.getZip() + "</td>");
                    out.println("<td><a href='delAdd?del_id=" + ad.getAddressId() + "&cId=" + cid + "'>Delete</a>"
                            + "<a href='operationAdd?edit_id=" + ad.getAddressId() + "&cId=" + cid + "''>Update</a>"
                            + "</td>");

                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("<a href='getCustomer'>Back</a>");
                out.println("</div>");
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
